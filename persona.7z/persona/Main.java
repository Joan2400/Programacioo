package persona;

public class Main {

	public static void main(String[] args) {
		
		Coche c1 = new Coche("Renault", "Rojo", "Clio");
		Estudiante e1 = new Estudiante("Juan", "1�DAM", 12345);
		e1.setEdad(20);
		e1.setsuCoche(c1);
		
		System.out.println(e1.getNombre() +" Nota media: " + e1.notaMedia());
		
		
		Profesor p1 = new Profesor("Fernando", "D104");
		Coche c2 = new Coche("Opel", "Blanco", "Corsa");
		
		p1.setEdad(45);
		p1.setsuCoche(c2);
		p1.setHorarioTutorias("Lunes de 10:00 a 13:00");
		
		System.out.println(p1.getNombre() + " " + p1.getConsultas());

	}

}
