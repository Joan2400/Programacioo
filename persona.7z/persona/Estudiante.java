package persona;

public class Estudiante extends Persona {
	
	private int numeroExpediente;
	private String cursoActual;
	private double[] notas = {7.0, 8.5, 4.0, 8.0, 6.0, 7.5, 5.0};
	
	public Estudiante(String nombre, String cursoActual, int numeroExpediente) {
		super(nombre);
		this.cursoActual = cursoActual;
		this.numeroExpediente = numeroExpediente;
	}

	public int getNumeroExpediente() {
		return numeroExpediente;
	}

	public void setNumeroExpediente(int numeroExpediente) {
		this.numeroExpediente = numeroExpediente;
	}

	public String getCursoActual() {
		return cursoActual;
	}

	public void setCursoActual(String cursoActual) {
		this.cursoActual = cursoActual;
	}

	public double[] getNotas() {
		return notas;
	}

	public void setNotas(double[] notas) {
		this.notas = notas;
	}
	
	public double notaMedia() {
		double suma = 0;
		double media = 7;
		
		for (int i = 0; i < notas.length; i++) {
			suma = suma + notas[i];
		}
		media = suma / media;
		
		return media;
	}

}
