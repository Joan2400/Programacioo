package persona;

public class Profesor extends Persona{
	
	public Profesor(String nombre, String despacho) {
		super(nombre);
		this.despacho = despacho;
	}

	private String despacho;
	private String horarioTutorias;
	public String getDespacho() {
		return despacho;
	}
	public void setDespacho(String despacho) {
		this.despacho = despacho;
	}
	public String getHorarioTutorias() {
		return horarioTutorias;
	}
	public void setHorarioTutorias(String horarioTutorias) {
		this.horarioTutorias = horarioTutorias;
	}
	
	public String getConsultas() {
		String cadena = "";
		
		cadena =  "tiene turoria " + this.horarioTutorias + " en el despacho " + this.despacho;
		
		return cadena;
	}

}
