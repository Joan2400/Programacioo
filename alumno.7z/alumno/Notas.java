package alumno;

import java.util.Scanner;

public class Notas {
	
	private double [] notas;
	
	public Notas() {
		
		this.notas = new double [5];
	}
	
	

	public double[] getNotas() {
		return notas;
	}



	public void setNotas(double[] notas) {
		this.notas = notas;
	}



	public void leer() {
		
		Scanner sc = new Scanner(System.in);
		
		for (int i = 0; i < notas.length; i++) {
			System.out.println("Dame una nota");
			notas[i] = sc.nextDouble();
		}
	}
	
	public double media() {
		
		double media = 0;
		double suma = 0;
		
		for (int i = 0; i < notas.length; i++) {
			suma = suma + notas[i];
		
		}
		media = suma / notas.length;
		
		return media;
	}
	
	public String toString() {
		
		String cadena = "";
		
		for (int i = 0; i < notas.length; i++) {
			cadena = cadena + "Nota " + (i + 1) + ":" + notas[i] + "\n";
		}
		
		return cadena;
	}
}
