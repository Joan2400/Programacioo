package alumno;

public class Alumno {
	
	private String nombre;
	private int expediente;
	private Notas notasAlumnos;
	
	
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getExpediente() {
		return expediente;
	}

	public void setExpediente(int expediente) {
		this.expediente = expediente;
	}

	public Notas getNotasAlumnos() {
		return notasAlumnos;
	}

	public void setNotasAlumnos(Notas notasAlumnos) {
		this.notasAlumnos = notasAlumnos;
	}

	public Alumno() {
		
	}
	
	public Alumno(String nombre, int expediente, Notas notasAlumnos) {
		this.nombre = nombre;
		this.expediente = expediente;
		this.notasAlumnos = notasAlumnos;
	}
	
	public String toString() {
		
		String cadena = "hola";
		
		cadena = "Alumno: " + this.nombre + " Numero expediente: " + this.expediente + "\n";
		cadena = cadena + "-----Notas----" + "\n" + notasAlumnos.toString();
		cadena = cadena + "Nota media: " + notasAlumnos.media();
		
		return cadena;
		
	}
	

}
