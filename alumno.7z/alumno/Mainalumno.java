package alumno;

public class Mainalumno {

	public static void main(String[] args) {
		
		Alumno alumno = new Alumno();
		Notas notas = new Notas();
		
		alumno.setNombre("Pepe");
		alumno.setExpediente(1234);
		notas.leer();
		alumno.setNotasAlumnos(notas);
		System.out.println(alumno.toString());
		
		
		
		
		Notas notas2 = new Notas();
		notas2.leer();
		Alumno alumno2 = new Alumno("Pedro", 2345, notas2);
		System.out.println(alumno2.toString());

	}

}
