package producto;

/**
 * 
 * @author Joan Pe�arrocha Crespo
 * Ejercicio evaluable 2 T8 - Herencia clase no perecedero
 *
 */

public class NoPerecedero extends Producto{
	
	//Atributos de la clase no perecedero
	private String tipo;
	
	//Constructor por defecto
	public NoPerecedero() {
		
	}
	
	//Constructor con parametros de la clase no perecedero junto con los parametros de Producto
	public NoPerecedero(String nombre, double precio, String tipo) {
		
		super(nombre,precio);
		this.tipo = tipo;
		
	}

	//Getters and Setters
	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	//Metodo heredado de la clase Producto que hace lo mismo, calcula el precio total del producto segun la cantidad
	@Override
	public double calcular(int cantidad) {
		
		return super.calcular(cantidad);
	}
	
	

}
