package producto;

/**
 * 
 * @author Joan Pe�arrocha Crespo
 * Ejercicio evaluable 2 T8 - Herencia clase Main
 *
 */


public class Main {

	public static void main(String[] args) {
		
	//Atributos para poder sumar el total de todos los productos que vamos a crear
	double precioTotalp = 0;
	double precioTotalnp = 0;
	double preciototalP = 0;
		
	//Aqui creamos un array del objeto Producto y creamos los objetos que son hijas dentro de ese array 
		 Producto productos[]=new Producto[15];
		 
		 //Objetos de tipo Producto
		 productos[0] = new Producto("Coca-cola", 1.56);
		 productos[1] = new Producto ("Fanta", 1.25);
		 productos[2] = new Producto ("Monster", 1.15);
		 productos[3] = new Producto ("Vino", 3.50);
		 productos[4] = new Producto ("Ginebra", 11.50);
		 
		 //Objetos de tipo Perecedero
		 productos[5] = new Perecedero("Lomo", 7.00, 3); 
		 productos[6] = new Perecedero ("Hamburguesa", 5.00, 1);
		 productos[7] = new Perecedero ("Costilla", 12.00, 5);
		 productos[8] = new Perecedero ("Alitas", 13.00, 8);
		 productos[9] = new Perecedero ("Queso", 7.00, 2); 
		 
		 //Objetos de tipo No Perecedero
		 productos[10] = new NoPerecedero("Cereales", 5.00, "Chocolate");
		 productos[11] = new NoPerecedero("Donuts", 3.00, "Azucar");
		 productos[12] = new NoPerecedero("Tabla de chocolate", 5.00, "Blanco");
		 productos[13] = new NoPerecedero("Rosquilletas", 1.58, "De pipas");
		 productos[14] = new NoPerecedero("Napolitana" , 1.24, "De jamon y queso");
		 
		//Aqui se suman los diferentes productos para poder saber el precio total
		 for (int cont = 0; cont < productos.length; cont++) {
			   
			 //Suma total de todos los productos creados de Perecedero
			 if(productos[cont] instanceof Perecedero) {
					 
			 precioTotalp = productos[cont].calcular(4) + precioTotalp;
				 
			 }
			 
			 //Suma total de todos los productos de No Perecedero
			 else if(productos[cont] instanceof NoPerecedero) {
				 
				 precioTotalnp = productos[cont].calcular(3) + precioTotalnp;
			 }
			 
			 //Suma total de todos los productos de Producto
			 else if (productos[cont] instanceof Producto) {
				 
				 preciototalP = productos[cont].calcular(2) + preciototalP;
			 }
			 
		 }
		 
		//Resultado final de todos los productos y la informacion del nombre y precio de un producto
		 System.out.println("El precio total de los no perecederos es: " + precioTotalnp);
		 System.out.println("El precio total de los perecederos es: " + precioTotalp);
		 System.out.println("El precio total de los productos es: " + preciototalP);
		System.out.println(productos[0].toString());
	}

}
