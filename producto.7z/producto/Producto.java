package producto;

/**
 * 
 * @author Joan Pe�arrocha Crespo
 * Ejercicio evaluable 2 T8 - Herencia clase producto
 *
 */

public class Producto {
	
	//Atributos del producto
	private String nombre;
	private double precio;
	
	//Constructor por defecto
	public Producto() {
		
	}
	
	//Constructor con los parametros
	public Producto (String nombre, double precio) {
		this.nombre = nombre;
		this.precio = precio;
	}

	//Getters and Setters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	
	//Metodo para calcular el precio total del producto segun la cantidad que se vaya a comprar
	public double calcular(int cantidad) {
		
		return this.precio * cantidad;
	}
	
	//Metodo para que muestre la informacion del producto
	public String toString() {
		
		String cadena = "";
		
		cadena = "El nombre del producto es: "+ this.nombre + "\n";
		cadena = cadena + "El precio del producto es: " + this.precio;
		
		return cadena;
	}
	

}
