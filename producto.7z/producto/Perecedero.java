package producto;

/**
 * 
 * @author Joan Pe�arrocha Crespo
 * Ejercicio evaluable 2 T8 - Herencia clase perecedero
 *
 */

public class Perecedero extends Producto{
	
	//Atributo de la clase Perecedero
	private int diasACaducar;
	
	//Constructor por defecto
	public Perecedero() {
		
	}
	
	//Constructor con los parametros de la clase Perecedero junto con los parametros de la clase Producto
	public Perecedero(String nombre, double precio, int diasACaducar) {
		
		super(nombre,precio);
		this.diasACaducar = diasACaducar;
	}

	//Getters and Setters
	public int getDiasACaducar() {
		return diasACaducar;
	}

	public void setDiasACaducar(int diasACaducar) {
		this.diasACaducar = diasACaducar;
	}
	
	//Metodo heredado de la clase Producto que calcula lo mismo pero se diferencia por si le queda poco para caducar divide el precio para que coste menos
	@Override
	public double calcular(int cantidad) {
		
		double precioFinal = 0;
		
		precioFinal = super.calcular(cantidad);
				
		
		if (this.diasACaducar == 1) {
			precioFinal = precioFinal / 4;
		}
		else if (this.diasACaducar == 2) {
			precioFinal = precioFinal /3;
		}
		else if (this.diasACaducar == 3) {
			precioFinal = precioFinal/2;
		}
		
		return precioFinal;
	}
	

}
