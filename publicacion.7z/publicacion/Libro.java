package publicacion;

public class Libro extends Publicacion{
	
	
	//Atributos de la clase Libro
	private String autor;

	//Constructor con parametros heredados de la clase Publicacion mas su atributo
	public Libro(int c, String a, String autor) {
		super(c, a);
		this.autor = autor;
	}

	//Getters and Setters
	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}
	
	//Metodo heredado de la clase Publicacion que muestra la informacion de esa clase mas la informacion de su atributo
	public String toString() {
		
		String cadena = "";
		
		cadena = super.toString() + "\n" + "Autor del libro: " + this.autor;
		
		return cadena;
	}
	
	

}
