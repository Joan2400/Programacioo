package publicacion;

public class Main {

	public static void main(String[] args) {
	
	//Atributo para poder contar cuantas publicaciones hay prestadas
	int cont = 0;
	
	
	//Aqui creamos un array del objeto Publicacion y creamos los objetos que son hijas dentro de ese array 
	Publicacion publi[] = new Publicacion[6];
	
	publi[0] = new Libro(1, "2020", "Pablo");
	publi[1] = new Revista(2, "2019", 4);
	publi[2] = new Publicacion(4, "2018");
	publi[3] = new Libro(3, "2017", "Pedro");
	publi[4] = new Revista(5, "2017", 5);
	publi[5] = new Publicacion(5, "2021");
	
	//Las publicaciones que estan prestadas
	publi[0].setPrestado(true);
	publi[2].setPrestado(true);
	publi[4].setPrestado(true);
	
	//Para poder mostrar la informacion de las diferentes publicaciones y saber si estan prestados o no
	for (int i = 0; i < publi.length; i++) {
		System.out.println(publi[i].toString());
		publi[i].prestar();
		publi[i].devolver();
		System.out.println("----------------------------");
		
		if(publi[i].prestado == true) {
			cont++;
		}
	}

	//Para saber cuantas publicaciones estan prestados
	System.out.println("Hay prestados: " + cont + " publicaciones");
	
	}

}
