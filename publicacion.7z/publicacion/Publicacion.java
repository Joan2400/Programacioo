package publicacion;

public class Publicacion implements Metodos {
	
	
	//Atributos de la clase Publicacion
	protected int codigo;
	protected String a�o;
	protected boolean prestado;
	
	
	//Constructor con parametros
	public Publicacion(int c, String a) {
		this.codigo = c;
		this.a�o = a;
	}

	//Getters and Setters
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getA�o() {
		return a�o;
	}

	public void setA�o(String a�o) {
		this.a�o = a�o;
	}

	public boolean isPrestado() {
		return prestado;
	}

	public void setPrestado(boolean prestado) {
		this.prestado = prestado;
	}

	//Metodo para saber si el libro o la revista aun sigue prestado o no
	@Override
	public void prestar() {
	
		if (prestado() == true) {
			
			System.out.println("Sigue prestado");
		}
		else {
			System.out.println("Ya no esta prestado");
		}
	
		
	}

	//Metodo para saber si el libro o la revista se ha devuelto o no
	@Override
	public void devolver() {
		
	if (prestado() == true) {
		
		System.out.println("No ha sido devuelto");
	}
	else {
		System.out.println("Ha sido devuelto");
	}
		
		
	}

	//Metodo para ver si sigue prestado o no la publicacion
	@Override
	public boolean prestado() {
		
		boolean res = false;
		
		if (this.prestado == true) {
			res = true;
		}
		
		return res;
	}
	
	//Metodo String para poder ver toda la informacion de la clase publicacion
	public String toString() {
		
		String cadena="";
		
		cadena = "C�digo de la publicacion: " + this.codigo +"\n";
		cadena = cadena + "A�o de la publicaci�n: "+ this.a�o + "\n";
		cadena = cadena + "Prestado: " + this.prestado;
		
		
		return cadena;
	}
	

}
