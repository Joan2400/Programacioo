package publicacion;

public class Revista extends Publicacion{
	
	//Atributos de la clase Revista
	private int numero;

	
	//Constructor con parametros heredados de la clase Publicacion mas su atributo
	public Revista(int c, String a, int numero) {
		super(c, a);
		this.numero = numero;
	}

	//Getters and Setters
	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	//Metodo heredado de la clase Publicacion que muestra la informacion de esa clase mas la informacion de su atributo
	public String toString() {
		
		String cadena = "";
		
		cadena = super.toString() + "\n" + "Numero de la revista: " + this.numero;
		
		return cadena;
	}
}
