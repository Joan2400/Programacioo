package publicacion;

public interface Metodos {
	
	//Metodos que se van a implementar en la clase Publicacion
	public void prestar();
	public void devolver();
	public boolean prestado();

}
