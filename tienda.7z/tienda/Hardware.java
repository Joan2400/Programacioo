package tienda;

public class Hardware extends Producto{
	
	private boolean periferico;
	
	public Hardware(char codigo, String descripcion, boolean periferico) {
		super(codigo, descripcion);
		this.periferico = periferico;	
	}
	
	

	public boolean isPeriferico() {
		return periferico;
	}



	public void setPeriferico(boolean periferico) {
		this.periferico = periferico;
	}


	@Override
	public double getPrecio() {
		
		double precioFinal = 0;
		
		if (codigo == 'B') {
			if (periferico == true) {
				precioFinal = B + (B * 0.1);
			}
			else {
				precioFinal = B;
			}
		}
		
		if (codigo == 'A'){
			if (periferico == true) {
				precioFinal = A + (A* 0.1);
			}
			else {
				precioFinal = A;
			}
		}
		return precioFinal;
	}

}
