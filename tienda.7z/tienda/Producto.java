package tienda;

public abstract class Producto implements IPrecios{
	
	protected char codigo;
	protected String descripcion;
	
	public Producto(char codigo, String descripcion) {
		
		this.codigo = codigo;
		this.descripcion = descripcion;
	}

	public char getCodigo() {
		return codigo;
	}

	public void setCodigo(char codigo) {
		this.codigo = codigo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	

}
