package tienda;

public class Main {

	public static void main(String[] args) {
		
		
		Producto hardware = new Hardware('A', "Raton", true);
		Producto Software = new Software('C', "Sistema operativo", "ProgramaJuegos");
		
		System.out.println(hardware.getPrecio());
		System.out.println(Software.getPrecio());

	}

}
