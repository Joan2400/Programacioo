package tienda;

public interface IPrecios {
	
	public static final double A = 100;
	public static final double B = 50.3;
	public static final double C = 150.5;
	
	double getPrecio();
	

}
