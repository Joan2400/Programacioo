package tienda;

public class Software extends Producto{
	
	private String tipo;

	public Software(char codigo, String descripcion, String tipo) {
		super(codigo, descripcion);
		this.tipo = tipo;
		
	}
	
	

	public String getTipo() {
		return tipo;
	}



	public void setTipo(String tipo) {
		this.tipo = tipo;
	}



	@Override
	public double getPrecio() {
		double precioFinal = 0;
		
		
		if (codigo == 'B') {
			if (tipo.equals("ProgramaJuegos")) {
				precioFinal = B + (B * 0.05);
			}
			else {
				precioFinal = B;
			}
		}
		
		
		if (codigo == 'C'){
			if (tipo.equals("ProgramaJuegos")) {
				precioFinal = C + (C* 0.05);
			}
			else {
				precioFinal = C;
			}
		}
		
		
		return precioFinal;
	}
	
	

}
