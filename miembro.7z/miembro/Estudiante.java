package miembro;

import java.util.Scanner;

public class Estudiante extends MiembroUPV {
	
	private int numeroExpediente;
	private String cursoActual;
	private double[] notas = {7.0, 8.5, 4.0, 8.0, 6.0, 7.5, 5.0};
	
	public Estudiante(String nombre, String cursoActual, int numeroExpediente) {
		super(nombre);
		this.cursoActual = cursoActual;
		this.numeroExpediente = numeroExpediente;
	}

	public int getNumeroExpediente() {
		return numeroExpediente;
	}

	public void setNumeroExpediente(int numeroExpediente) {
		this.numeroExpediente = numeroExpediente;
	}

	public String getCursoActual() {
		return cursoActual;
	}

	public void setCursoActual(String cursoActual) {
		this.cursoActual = cursoActual;
	}

	public double[] getNotas() {
		return notas;
	}

	public void setNotas(double[] notas) {
		this.notas = notas;
	}
	
	public double notaMedia() {
		double suma = 0;
		double media = 7;
		
		for (int i = 0; i < notas.length; i++) {
			suma = suma + notas[i];
		}
		media = suma / media;
		
		return media;
	}

	@Override
	public void menuIntranet() {
		
		 Scanner sc = new Scanner(System.in);
			
			int opcion;
			String actividades;
			
			do {
				
				
					System.out.println("Bienvenido al men� Intranet estudiante, seleccione la operaci�n que desee hacer:");
					System.out.println("1- Ver expediente estudiante");
					System.out.println("2- �A qu� actividades deportivas desea apuntarse?");
					System.out.println("3- SALIR");
					opcion = sc.nextInt();
					
					switch(opcion) {
					
					case 1: 
						System.out.println("Nombre: " + getNombre());
						System.out.println("Edad: " + getEdad());
						System.out.println("Expediente: " + this.numeroExpediente);
						System.out.println("Curso: " + this.cursoActual);
						break;
					case 2:
						System.out.println("Introduce las actividades a las que quiere apuntarse:");
						 actividades = sc.next();
						 
						 
						break;
					case 3:
						System.out.println("HASTA LUEGO! Gracias por utilizar la Intranet de estudiante");
						break;
					}	
					
				
			}
			while (opcion != 3);
		
	}

}
