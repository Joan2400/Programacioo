package miembro;

public abstract class MiembroUPV extends Persona{
	
	private String carnet;

	public String getCarnet() {
		return carnet;
	}

	public void setCarnet(String carnet) {
		this.carnet = carnet;
	}

	public MiembroUPV(String nombre) {
		super(nombre);
		
	}
	
	public abstract void menuIntranet();

}
