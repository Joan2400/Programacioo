package miembro;

public class Main {

	public static void main(String[] args) {
		
		MiembroUPV estudiante = new Estudiante("Jose", "1� ESO", 2134524);
		MiembroUPV profesor = new Profesor("Pablo", "1� de filosofia", 1567.50, "8:00 - 13:00");
		
		profesor.setEdad(27);
		estudiante.setEdad(15);
		
		estudiante.menuIntranet();
		profesor.menuIntranet();

	}

}
