package miembro;

import java.util.Scanner;

public class Profesor extends MiembroUPV{
	
	private double nomina;
	private String despacho;
	private String horarioTutorias;
	
	public Profesor(String nombre, String despacho, double nomina, String horarioTutorias) {
		super(nombre);
		this.despacho = despacho;
		this.nomina = nomina;
		this.horarioTutorias = horarioTutorias;
	}
	
	public double getNomina() {
		return nomina;
	}
	public void setNomina(double nomina) {
		this.nomina = nomina;
	}
	
	public String getDespacho() {
		return despacho;
	}
	public void setDespacho(String despacho) {
		this.despacho = despacho;
	}
	public String getHorarioTutorias() {
		return horarioTutorias;
	}
	public void setHorarioTutorias(String horarioTutorias) {
		this.horarioTutorias = horarioTutorias;
	}
	
	public String getConsultas() {
		String cadena = "";
		
		cadena =  "tiene turoria " + this.horarioTutorias + " en el despacho " + this.despacho;
		
		return cadena;
	}
	@Override
	public void menuIntranet() {
		
		 Scanner sc = new Scanner(System.in);
		
		int opcion;
		String actividades;
		
		do {
			System.out.println("Bienvenido al men� Intranet profesor, seleccione la operaci�n que desee hacer:");
			System.out.println("1- Ver la informaci�n del profesor");
			System.out.println("2- Ver n�mina del profesor");
			System.out.println("3- �A qu� actividades deportivas desea apuntarse?");
			System.out.println("4- SALIR");
			opcion = sc.nextInt();
			
			switch(opcion) {
			
			case 1: 
				System.out.println("Nombre: " + getNombre());
				System.out.println("Edad: " + getEdad());
				System.out.println("Despacho: " + this.getDespacho());
				System.out.println("Horario: " + this.getHorarioTutorias());
				break;
			case 2:
				System.out.println("La nomina del profesor es: " + this.getNomina());
				break;
			case 3:
				System.out.println("Introduce las actividades a las que quiere apuntarse:");
				actividades = sc.next();
				break;
			case 4:
				System.out.println("HASTA LUEGO! Gracias por utilizar la Intranet de profesor");
				break;
			}	
			
		}
		while (opcion != 4);
		
	}

}
