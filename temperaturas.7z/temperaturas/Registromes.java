package temperaturas;

public class Registromes {
	
	private String nombreMes;
	private int a�o;
	private Temperaturas temp;
	
	public Registromes() {
		
	}
	
	public Registromes(String nombreMes, int a�o, Temperaturas 	temp) {
		this.nombreMes = nombreMes;
		this.a�o = a�o;
		this.temp = temp;
	}
	
	
	
	public String getNombreMes() {
		return nombreMes;
	}

	public void setNombreMes(String nombreMes) {
		this.nombreMes = nombreMes;
	}

	public int getA�o() {
		return a�o;
	}

	public void setA�o(int a�o) {
		this.a�o = a�o;
	}

	public Temperaturas getTemp() {
		return temp;
	}

	public void setTemp(Temperaturas temp) {
		this.temp = temp;
	}

	public String toString() {
		String cadena = "";
		
		cadena = "Registro de temperaturas del mes " + this.nombreMes + " del a�o " + this.a�o + "\n";
		cadena = cadena + "--------Temperaturas---------" + "\n";
		for (int i = 0; i < temp.mostrar().length;i++) {
			cadena = cadena  +"Dia " +(i + 1) +": " + temp.mostrar()[i] + "\n";
		}
		cadena = cadena + "Temperatura media: " + temp.media() + "\n";
		cadena = cadena + "Temperatura m�xima: " + temp.maxima() + ", " + "Temperatura minima: " + temp.minima();
		
		return cadena;
	}

}
