package temperaturas;

import java.util.Scanner;

public class Temperaturas {
	
	private double[] temp;
	
	public Temperaturas() {
		this.temp = new double [31];
		int mes = 6;
		
		if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
			this.temp = new double [30];
		}
		
		if (mes == 2) {
			this.temp = new double [28];
		}
		
		
		
	}

	public double[] getTemp() {
		return temp;
	}

	public void setTemp(double[] temp) {
		this.temp = temp;
	}
	
	public void leer() {
		
		Scanner sc = new Scanner(System.in);
		
		for (int i = 0; i < temp.length; i++) {
			System.out.println("Dame la temperatura del dia " + (i + 1));
			this.temp[i] = sc.nextDouble();
		}
	}
	
	public double media() {
		double suma = 0;
		double media = 0;
		
		for (int i = 0; i < temp.length; i++) {
			suma = suma + this.temp[i];
		}
		
		media = suma / temp.length;
		
		return media;
	}
	
	public double[] mostrar() {
			 return temp;
		
	}
	
	public double maxima() {
		
		double max = -100000;
		
		for (int i = 0; i < temp.length; i++) {
			if (temp[i] > max) {
				max = temp[i];
			}
		}
		
		
		return max;
	}
	
	public double minima() {
		
		double min = 1000000;
		
		for (int i = 0; i < temp.length; i++) {
			if (temp[i] < min) {
				min = temp[i];
			}
		}
		
		return min;
	}

}
