package temperaturas;

public class Maintemp {

	public static void main(String[] args) {
		
		
		Temperaturas temp = new Temperaturas();
		temp.leer();
		Registromes registro = new Registromes("Junio", 2002, temp);
		System.out.println(registro.toString());
		

	}

}
