package empleado;

public class Main {

	public static void main(String[] args) {
		
		Programador p = new Programador ("Pepe", "45326356G", 19, false, 2345,300, "Java");
		
		p.mostrarDatos();
		System.out.println(p.clasificacion());
		p.aumentarSueldo(25);
		System.out.println("Salario: " + p.getSalario());
		p.mostrarMensaje("Buen programador");
		System.out.println(p.nivelProgramacion());
		

	}

}
