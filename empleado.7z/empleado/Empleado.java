package empleado;

public class Empleado {
	
	private String nombre;
	private String dni;
	private int edad;
	private boolean casado;
	private double salario;
	
	public Empleado() {
		
	}
	
	public Empleado(String nombre, String dni, int edad, boolean casado, double salario) {
		
		this.nombre = nombre;
		this.dni = dni;
		this.casado = casado;
		this.salario = salario;
		
		if (edad >= 18 || edad <= 45) {
			this.edad = edad;
		}
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public boolean isCasado() {
		return casado;
	}

	public void setCasado(boolean casado) {
		this.casado = casado;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}
	
	public String clasificacion() {
		
		String tipo = "";
		
		if (this.edad == 18) {
			tipo = "Novato";
		}
		else if (this.edad >= 19 || this.edad <= 25) {
		 	tipo = "Junior";
		}
		else if (this.edad > 25) {
			tipo="Senior";
		}
		
		return tipo;
		
		
	}
	
	public void mostrarDatos() {
		
		
		System.out.println("Nombre: " + this.nombre);
		System.out.println("DNI: " + this.dni);
		System.out.println("Edad: " + this.edad);
		if (this.casado == true) {
			System.out.println("Casado: Si");
		}
		else {
			System.out.println("Casado: No");
		}
		System.out.println("Salario: " + this.salario);
		
	}
	
	public double aumentarSueldo(double aumento) {
		
		double total = 0;
		
		aumento = aumento/100;
		total = this.salario * aumento;
		this.salario = this.salario +total;
		
		
		return this.salario;	
		
	}
	
	public void mostrarMensaje(String mensaje) {
		
		System.out.println(mensaje);
	}
	

}
